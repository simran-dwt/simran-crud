<?php
include "crud.php";
if(isset($_GET['id'])){
    $id =$_GET['id'];
    $sql ="DELETE from crud where id=$id";
    $conn->query($sql);
}
header('location:index.php');
exit;
?>


