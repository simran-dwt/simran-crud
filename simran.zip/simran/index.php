<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.0.2/dist/css/bootstrap.min.css" rel="stylesheet" integrity="sha384-EVSTQN3/azprG1Anm3QDgpJLIm9Nao0Yz1ztcQTwFspd3yD65VohhpuuCOmLASjC" crossorigin="anonymous">
    
    
    <script src="https://ajax.googleapis.com/ajax/libs/jquery/3.7.1/jquery.min.js"></script>
    
    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.0.2/dist/js/bootstrap.bundle.min.js" integrity="sha384-MrcW6ZMFYlzcLA8Nl+NtUVF0sA7MsXsP1UyJoMp4YLEuNSfAP+JcXn/tWtIaxVXM" crossorigin="anonymous"></script>
    <script src="https://maxcdn.bootstrapcdn.com/bootstrap/3.4.1/js/bootstrap.min.js"></script>
    <title>Document</title>
   
</head>
<body>
    
    <nav class="navbar navbar-expand-lg navbar-dark bg-dark">
        <div class="container-fluid bg-dark">
            <a class="navbar-brand" href="index.php">PHP CRUD OPERATION</a>
            <div class="collapse navbar-collapse" id="navbarNav">
                <ul class="navbar-nav">
                    <li class="nav-item">
                        <a class="nav-link active" aria-current="page" href="index.php">HOME</a>
</li>
<li class="nav-item">
    <a type='button'  class=" btn btn-primary nav-link active" href="create.php">Add New</a>
</li>
</ul>
</div>
</nav>
<table class="table">
  <thead>
    <tr>
      <th> ID</th>
      <th>NAME</th>
      <th>EMAIL </th>
      <th>PASSWORD</th>
      <th>PHONE</th>
    </tr>
  </thead>7
  <tbody>
    <?php
    include"crud.php";
    $sql = "select * from crud";
    $result =$conn->query($sql);
    if(!$result){
        die("Invalid query!");
    }
    while($row=$result->fetch_assoc()){
        echo "
    <tr>
      <th>$row[id]</th>
      <td>$row[name]</td>
      <td>$row[email]</td>
      <td>$row[password]</td>
      <td>$row[phone]</td>
      <td>
          <a class='btn btn-primary' href='update.php?id=$row[id]'>Edit</a>
          <a class='btn btn-danger' href='delete.php?id=$row[id]'>Delete</a>
    </tr>
    ";
    }
    ?>
  </tbody>
</table>
</body>
</html>